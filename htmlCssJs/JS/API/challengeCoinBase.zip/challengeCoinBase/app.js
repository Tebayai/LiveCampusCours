const priceContainer = document.querySelector('#Price-container');
const priceCryptos = document.querySelector('#price-cryptos');
const textCryptosResponse = result => `Prix d'achat du ${result.crypto} en EUR : ${result.price}€`;
const updateInterval = 60000;

/* Affichage du loader pendant la récupération du prix */
const showLoader = element =>{
    element.textContent = 'Chargement...';
    element.className = 'loading';
};

/* Affichage de la variation des prix vert=>Monte rouge=>Baisse gris=>Stable */
let previousPrices = {};

function previousPrice(crypto, currentPrice) {
    currentPrice = Number(currentPrice);
    const lastPrice = previousPrices[crypto];
    previousPrices[crypto] = currentPrice;
    if (lastPrice === undefined) return 'gris';
    if (currentPrice > lastPrice) return 'vert';
    if (currentPrice < lastPrice) return 'rouge';
    return 'gris';
}

/* Fetch unique crypto */
const fetchPrices = crypto =>
    fetch(`https://api.coinbase.com/v2/prices/${crypto}-EUR/buy`)
        .then(response =>{
            if(!response.ok){
                throw new Error('Erreur Coinbase api');
            }
            return response.json();
        })
        .then(data =>{
            const price = data.data.amount;
            return {crypto: crypto, price};
        });

/* Récupérer le prix du BTC en euro */
const fetchBTCPrice = () =>{
    showLoader(priceContainer);
    fetchPrices('BTC')
        .then(result =>{
            priceContainer.textContent = `Prix d'achat du BTC en EUR : ${result.price}€`;
            priceContainer.className = previousPrice('single-BTC', result.price);
        })
        .catch(error =>{
            priceContainer.textContent = 'Erreur';
            priceContainer.className = '';
        });
};

fetchBTCPrice();
setInterval(fetchBTCPrice, updateInterval);

/* Récupérer les prix des 6 cryptos en euro */
const cryptos = ['BTC', 'ETH', 'ADA', 'DOT', 'CRO', 'MATIC'];

const updateAllPrices = () =>{
    priceCryptos.innerHTML = '<li class="loading">Chargement...</li>';
    Promise.all(cryptos.map(fetchPrices))
        .then(results =>{
            priceCryptos.innerHTML = results.map(result =>
                `<li class="${previousPrice(`list-${result.crypto}`, result.price)}">${textCryptosResponse(result)}</li>`
            ).join('');
        })
        .catch(error =>{
            priceCryptos.textContent = 'Erreur';
        });
};

updateAllPrices();
setInterval(updateAllPrices, updateInterval);

/* Récupérer le prix de la crypto select */
const cryptoSelect = document.querySelector('#crypto-select');
const selectedCryptoPrice = document.querySelector('#selected-crypto-price');
const selectedHistoryContainer = document.querySelector('.selected-history');

let intervalId;

const updateSelectedPrice = selectedCrypto =>{
    showLoader(selectedCryptoPrice);
    fetchPrices(selectedCrypto)
        .then(result =>{
            const trend = previousPrice(`select-${result.crypto}`, result.price);
            selectedCryptoPrice.textContent = textCryptosResponse(result);
            selectedCryptoPrice.className = trend;
            selectedHistoryContainer.innerHTML += `<li class="${trend}">${textCryptosResponse(result)}</li>`;
        })
        .catch(error =>{
            selectedCryptoPrice.textContent = 'Erreur';
            selectedCryptoPrice.className = '';
        });
};

cryptoSelect.addEventListener('change', () => {
    const selectedCrypto = cryptoSelect.value;
    clearInterval(intervalId);
    selectedHistoryContainer.innerHTML = '';
    updateSelectedPrice(selectedCrypto);
    intervalId = setInterval(() => updateSelectedPrice(selectedCrypto), updateInterval);
});